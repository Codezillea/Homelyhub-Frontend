import axios from "axios";

import { userActions } from "./user-slice";



export const getSignUp = (user) => async (dispatch) => {
    try {
        dispatch(userActions.getSignupRequest());

        const response = await axios.post("/api/v1/rent/user/signup", user);

      //  console.log(response);

        const { data } = response;

        dispatch(userActions.getSignUpDetails(data.user))


    }
    catch (error) {
        dispatch(userActions.getErrors(error.message))

    }
};

//handling user login

export const getLogIn = (user)=> async(dispatch)=>
{
    try{
        dispatch(userActions.getLoginRequest());

        const response = await axios.post("/api/v1/rent/user/login",user);

        const { data } = response;

        //console to see data and response

        dispatch(userActions.getLoginDetails(data.user));

    }
    catch(error)
    { 
        dispatch(userActions.getErrors(error.message));
    }
}

// get Current Information whoever logged in

export const currentUser = ()=> async(dispatch)=>
{
    try{
        dispatch(userActions.getCurrentUserRequest());

        const response = await axios.get("/api/v1/rent/user/me");
       
        const { data } = response;

        dispatch(userActions.getCurrentUser(data.user))

    }
    catch(error)
    {
        dispatch(userActions.getErrors(error.message));

    }
};

//  to update user Information

export const updateUser = (updateUser)=> async(dispatch)=>
{
    try{
        dispatch(userActions.getUpdateUserRequest());

       await axios.patch("/api/v1/rent/user/updateMe",updateUser);

       const response = await axios.get("/api/v1/rent/user/me");

       const{ data } = response;

       dispatch(userActions.getCurrentUser(data.user));

    }
    catch(error)
    {
        dispatch(userActions.getErrors(error.response.data.message));

    }
}

// to handle forgot password

export const forgotPassword = (email)=> async(dispatch)=>
{
    try{
        await axios.post("/api/v1/rent/user/forgotPassword",{email});
    }
    catch(error)
    {
        dispatch(userActions.getErrors(error.response.data.message));
    }
}

// to handle password reset

export const passwordReset =( resetPassword , token )=> async(dispatch)=>
{
    try{
        await axios.patch(`/api/v1/rent/user/resetPassword/${token}`,resetPassword);

    }
    catch(error)
    {
        dispatch(userActions.getErrors(error.response.data.message));
    }
}

// password update

export const updatePassword =  (passwords)=>async(dispatch)=>
{
    try{
        dispatch(userActions.getPasswordRequest())

        await axios.patch("/api/v1/rent/user/update/updateMyPassword",passwords);

        dispatch(userActions.getPasswordSuccess(true));

    }
    catch(error)
    {
        dispatch(userActions.getErrors(error.response.data.message));
    }
}

//user  Logout

export const Logout =()=>async(dispatch)=>
{
    try{
        //dispatch(userActions.getLogOutRequest());
        await axios.get("/api/v1/rent/user/logout");
        dispatch(userActions.getLogOut(null))
    }
    catch(error)
    {
        
        dispatch(userActions.getErrors(error));

    }
}