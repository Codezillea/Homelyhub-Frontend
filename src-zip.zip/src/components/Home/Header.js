import React from 'react'
import { Link, useNavigate } from 'react-router-dom';
import { useDispatch, useSelector } from 'react-redux';
import { toast } from "react-toastify";

import { Search } from "./Search";
import { Filter } from './Filter';
import { propertyAction } from '../../Store/Property/property-slice';
import { getAllProperties } from '../../Store/Property/property-action';
import { Logout } from "../../Store/User/user-action";

export const Header = () => {

  const dispatch = useDispatch();
  const { isAuthenticated, user } = useSelector((state) => state.user);
  const navigate = useNavigate();

  const log_out = () => {
    dispatch(Logout());
    toast.success(" Logged Out Successfully ");
    navigate("/");

  }




  const allproperties = () => {                                                                  //eslint-disable-line
    dispatch(propertyAction.updateSeachParameters({}));
    dispatch(getAllProperties());
  }
  return (
    <>
      <nav className=" header row sticky-top">
        <Link to="/"> <img src="/assets/logo.png" alt="homelyHub - logo" className="logo" /></Link>

        <div className="search_filter">
          <Search />
        </div>
        <Filter />
        {!isAuthenticated && !user && (
          <Link to="/login">
            <span className="material-symbols-outlined web_logo">
              account_circle
            </span>
          </Link>)}

        {isAuthenticated && user && (
          <div className="dropdown">
            <span
              className='material-symbols-outlined web_logo dropdown-toggle'
              href="#"
              role="button"
              id="dropdownMenuLink"
              aria-expanded="false"
            >
              { user.avatar.url && (
                <img
                  src={user.avatar.url}
                  className='user-img'
                  alt="icon" />
              )}

              {
                !user.avatar.url === "" && "account_circle"
              }
            </span>

            <ul className='dropdown-menu' aria-labelledby="dropdownMenuLink">
              <li>
                <Link className='dropdown-item' to="/profile">
                  {""}
                  My Account
                </Link>
              </li>

              <li>
                <button
                  className='dropdown-item'
                  type="button"
                  onClick={log_out}>
                  Log Out
                </button>
              </li>

            </ul>

          </div>
        )}
      </nav>
    </>


  )
}
