import React, { useState } from 'react'
import moment from 'moment'; //Moment made working with dates and time in Js much easier by providing more functions and utilities.
import { DatePicker, Space } from 'antd';
import { useDispatch } from 'react-redux';
import { useNavigate } from 'react-router-dom';


export const BookingForm = ({ price,
  propertyName,
  address,
  maximumGuest,
  currentBookings
}) => {
  const [paymentData, setPaymentData] = useState({});

  const [userData, setUserData] = useState({}); //eslint-disable-line

  const { RangePicker } = DatePicker;

  const dispatch = useDispatch();

  const navigate = useNavigate();

  const handleDateChange = (dateString) => {
    handleFilterChange("checkInDate", dateString[0]);
    handleFilterChange("chckOutDate", dateString[1]);

    const calculatedNights = moment(dateString[1], "YYYY-MM-DD").diff(
      moment(dateString[0], "YYYY-MM-DD"),
      "days" //difference in terms of day

    );


    const calculatedTotalPrice = price * calculatedNights;

    handleFilterChange("nights", calculatedNights);
    handleFilterChange("totalPrice", calculatedTotalPrice);



  };


  let disabledDates = [];

  currentBookings.forEach(
    (date) =>
      disabledDates.push({ start: date.fromDate, end: date.toDate }));

  const isDateDisabled = (current) => {
    if (!disabledDates.length) {
      return current.isBefore(Date.now(), "day");                          // it will disable all previous day from the current day
    }
    else {

      return disabledDates.some((date) => { //Array.some( (var) (iteration and condition)) return true or false
        const startDate = new Date(date.start);
        const endDate = new Date(date.end).setHours(233, 59, 59, 999);
        const currentDate = new Date(current);  //converting to json date object                            // current is passed as a parameter in isDateDisabled function .
        return (current.isBefore(Date.now(), "day") || (currentDate >= startDate && currentDate <= endDate))

        
        // condtion 1 checks whether the passed parameter is before the today's date or not and 
        //condition 2 will check whether the date whcich is passed is falls under the date constraints on cuurentBooking (already booked) dates or not 
        //Date.now(): This method returns the current timestamp in milliseconds since the Unix epoch (January 1, 1970, 00:00:00 UTC).
        //current.isBefore(Date.now(), "day"): This seems to be checking whether a given moment, represented by the variable current, is before the current day. The method isBefore() is likely a part of a date/time library, such as Moment.js or Luxon. It's used to compare two moments in time. In this case, it's checking if the moment represented by current is before the current day.
      })

    }
  }

  const handleFilterChange = (keyName, value) => {
    setPaymentData((prevData) => ({
      ...prevData,
      [keyName]: value,
    }))
  }
  return (
    <div className='form-container'>
      <form className='payment-form'>
        <div className="price-pernight">
          <b>&#8377;{price}</b> {/* #8377 - rupees symbol*/}
          <span>/ per night</span>
        </div>
        <div className="payment-field">
          <div className="date">
            <Space direction='vertical' size={"12"} >
              <RangePicker
                format="YYYY-MM-DD"
                disabledDate={isDateDisabled}
                onChange={handleDateChange}

              />

            </Space>
          </div>
          <div className="guest">
            <label className='payment-labels' >Number of Guests :</label>
            <br />
            <input
              type="number"
              className='no-of-guest'
              placeholder='Number of Guests'
              min="1"
              max={maximumGuest}
              required
              onChange={(e) =>
                setUserData((prev) => ({ ...prev, guests: e.target.value }))}
            />

          </div>
          <div className="name-phoneno">
            <label className='payment-labels'>Your Full Name:</label>
            <br />
            <input
              type="text"
              className='full-name'
              placeholder='Name'
              required
              onChange={(e) => setUserData((prev) => ({ ...prev, name: e.target.value }))}
              minLength="3"
            />
            <br />
            <label className='payment-labels'>Phone Number :</label>
            <br />
            <input
              type="tel"
              className='phone-no'
              placeholder='number'
              maxLength="10"
              required
              onChange={(e) => setUserData((prev) => ({ ...prev, number: e.target.value }))}
              pattern='[0-9]{10}'
            />
          </div>

        </div>
        <div className="book-place">
          <button>
            Book this place &#8377;{paymentData["totalPrice"] || 0}
          </button>
        </div>
      </form>

    </div>
  )
}
