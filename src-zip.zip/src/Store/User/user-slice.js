import { createSlice } from "@reduxjs/toolkit";

const userSlice = createSlice({
    name: "user",

    initialState : {


        isAuthenticated : false,
        loading : false,
        success : false,
        user: null,
        errors: null
        

    },
    reducers:
    {
        getSignupRequest(state)
        {
            state.loading = true ;
        },

        getSignUpDetails(state,action)
        {
            state.user = action.payload;
            state.isAuthenticated = true ;
            state.loading = false

        },

        getLoginRequest(state)
        {
            state.loading = true ;

        },

        getLoginDetails(state,action)
        {
            state.user = action.payload;
            state.isAuthenticated = true ;
            state.loading = false

        },


        getErrors(state,action)
        {
            state.errors = action.payload;
            state.loading = false
        },

        getCurrentUserRequest(state)
        {
            state.loading = true;
        },
        
        getCurrentUser(state,action)
        {
            state.user = action.payload ;
            state.isAuthenticated = true;
            state.loading = false;

        },

        getUpdateUserRequest(state)
        {
            state.loading = true ;
        },

        

        getLogOutRequest(state)
        {
            state.loading = true;
        },

        getLogOut(state,action)
        {
            state.user = action.payload ;
            state.isAuthenticated = false;
            state.loading = false;
        },

        getPasswordRequest(state)
        {
            state.loading = true;
        },

        getPasswordSuccess(state,action)
        {
            state.success = action.payload;
            state.loading = false;
        },
        
        clearError(state)
        {
            state.errors = null
        }
    }
});

export const userActions = userSlice.actions;

export default userSlice;