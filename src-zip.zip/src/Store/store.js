import { configureStore } from "@reduxjs/toolkit";

import propertySlice from "./Property/property-slice";
import propertyDetailsSlice from "./PropertyDetails/propertyDetails-slice";
import userSlice from "./User/user-slice";

const store = configureStore({
    reducer: {
        properties: propertySlice.reducer, //Adding our slice 
        propertydetails: propertyDetailsSlice.reducer, // Adding our slice for property details
        user : userSlice.reducer

    }
})
export default store;