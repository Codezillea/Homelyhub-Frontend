import React from 'react'
import { Routes, Route } from 'react-router-dom';

import { Main } from "../components/Home/Main";
import { PropertyList } from '../components/Home/PropertyList';
import { PropertyDetails } from '../components/PropertyDetails/PropertyDetails';
import { Login } from '../components/User/Login';
import { SignUp } from '../components/User/SignUp';


export const AllRoutes = () => {
    return (

        <Routes>

            <Route path="/" element={<Main />} exact> 
                <Route index element={<PropertyList />} />        {/*Nested Routes used */}
                <Route
                    path="propertylist/:id"
                    id="property-details"
                    element={<PropertyDetails />}
                />
                 <Route path="/login" id="login" element={<Login/>}/>

                 <Route path="/signup" id="signup" element={<SignUp/>} />
            </Route>
           
        </Routes>
    )
}
